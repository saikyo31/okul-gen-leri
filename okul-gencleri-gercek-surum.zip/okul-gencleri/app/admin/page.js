'use client';
import { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
const url=process.env.NEXT_PUBLIC_SUPABASE_URL, anon=process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
export default function Admin(){
 const [client,setClient]=useState(null),[session,setSession]=useState(null),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[msg,setMsg]=useState(''),[candidates,setCandidates]=useState([]),[students,setStudents]=useState(''),[codes,setCodes]=useState([]),[title,setTitle]=useState(''),[body,setBody]=useState('');
 useEffect(()=>{if(url&&anon){const c=createClient(url,anon);setClient(c);c.auth.getSession().then(({data})=>setSession(data.session));c.auth.onAuthStateChange((_e,s)=>setSession(s));}},[]);
 async function login(e){e.preventDefault();const {error}=await client.auth.signInWithPassword({email,password});setMsg(error?.message||'Giriş kontrol ediliyor...');}
 async function api(path,payload){const {data}=await client.auth.getSession();const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json',Authorization:`Bearer ${data.session.access_token}`},body:JSON.stringify(payload)});const j=await r.json();setMsg(j.message||j.error||'Tamamlandı');return j;}
 async function load(){const r=await fetch('/api/results');const j=await r.json();setCandidates(j.candidates||[]);}
 useEffect(()=>{if(session)load();},[session]);
 function updateCandidate(id,key,value){setCandidates(old=>old.map(c=>c.id===id?{...c,[key]:value}:c));}
 async function saveCandidates(){for(const c of candidates) await api('/api/admin/candidates',c);}
 async function createStudents(){const j=await api('/api/admin/students',{students:students.split('\n').map(x=>x.trim()).filter(Boolean)});if(j.codes)setCodes(j.codes);}
 async function makeCodes(){const j=await api('/api/admin/codes',{});if(j.codes)setCodes(j.codes);}
 async function announce(){await api('/api/admin/announcements',{title,body});setTitle('');setBody('');}
 function downloadCodes(){const csv='Öğrenci, Kod\n'+codes.map(c=>`${JSON.stringify(c.student)},${c.code}`).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob(['\ufeff'+csv],{type:'text/csv'}));a.download='ogrenci-kodlari.csv';a.click();}
 if(!client)return <main className="adminWrap"><h1>Yönetici paneli</h1><p>Supabase ayarları tamamlanmamış.</p></main>;
 if(!session)return <main className="adminWrap"><a href="/">← Siteye dön</a><h1>Yönetici girişi</h1><form onSubmit={login}><label>E-posta<input value={email} onChange={e=>setEmail(e.target.value)} type="email" required/></label><label>Şifre<input value={password} onChange={e=>setPassword(e.target.value)} type="password" required/></label><button>GİRİŞ YAP</button></form><p>{msg}</p></main>;
 return <main className="adminWrap"><header className="adminTop"><a href="/">← Siteyi görüntüle</a><button className="secondary" onClick={()=>client.auth.signOut()}>Çıkış</button></header><h1>Yönetim paneli</h1><p className="muted">Adaylar, öğrenci listesi, saatlik kodlar ve duyurular.</p><p className="message">{msg}</p>
 <section className="adminCard"><h2>Adayları düzenle</h2>{candidates.map((c,i)=><div className="editCandidate" key={c.id}><b>Aday {i+1}</b><input value={c.name||''} placeholder="Ad soyad" onChange={e=>updateCandidate(c.id,'name',e.target.value)}/><input value={c.slogan||''} placeholder="Slogan / vaat" onChange={e=>updateCandidate(c.id,'slogan',e.target.value)}/><input value={c.photo_url||''} placeholder="Fotoğraf bağlantısı (isteğe bağlı)" onChange={e=>updateCandidate(c.id,'photo_url',e.target.value)}/></div>)}<button onClick={saveCandidates}>ADAYLARI KAYDET</button></section>
 <section className="adminCard"><h2>Öğrencileri ekle</h2><p className="muted">Her satıra bir öğrenci numarası veya tanımlayıcı yaz. İsim yerine okul numarası kullanman daha gizlidir.</p><textarea rows="5" value={students} onChange={e=>setStudents(e.target.value)} placeholder={'1001\n1002\n1003'}/><button onClick={createStudents}>ÖĞRENCİLERİ KAYDET</button></section>
 <section className="adminCard"><h2>Bu saat için kod üret</h2><p className="muted">Kodları saat başlamadan üret ve ilgili öğrencilere özel olarak dağıt. Kod listesi yalnızca üretildiğinde gösterilir.</p><button onClick={makeCodes}>SAATLİK KODLARI ÜRET</button>{codes.length>0&&<><button className="secondary" onClick={downloadCodes}>CSV OLARAK İNDİR</button><div className="codeList">{codes.map(c=><p key={c.student}><b>{c.student}</b> — <code>{c.code}</code></p>)}</div></>}</section>
 <section className="adminCard"><h2>Duyuru yayınla</h2><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Duyuru başlığı"/><textarea rows="4" value={body} onChange={e=>setBody(e.target.value)} placeholder="Duyuru metni"/><button onClick={announce}>DUYURUYU YAYINLA</button></section>
 </main>;
}
